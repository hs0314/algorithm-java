#include <stdio.h>

int N, M;
char map[11][11];
int ind[11];
char A[] = "LRUD";
int qx[4] = {0, 0, -1, 1};
int qy[4] = {-1, 1, 0, 0};

int run(int x, int y, int dir){

	int cnt = 0;
	while (map[x][y] == '.'){
		cnt++;
		x += qx[dir], y += qy[dir];
	}

	if (map[x][y] == 'O')
		return cnt;

	return cnt - 1;

}
int check(int n){

	for (int i = 0; i < N; i++){
		for (int j = 0; j < M; j++){

			int x = i, y = j;
			if (map[x][y] != '.') continue;

			for (int k = 0; k < n; k++){
				int dir = ind[k];
				int size = run(x, y, dir);
				x += qx[dir] * size;
				y += qy[dir] * size;
				if (map[x][y] == 'O')
					break;
			}
			if (map[x][y] != 'O') return 0;

		}
	}
	return 1;

}
int dfs(int len){

	if (check(len)) {
		return len;
	}
	if (len == 10) return 0;

	for (int i = 0; i < 4; i++){
		if (len == 0 || ind[len - 1] != i) {
			ind[len] = i;
			int temp = dfs(len + 1);
			if (temp) return temp;
		}
	}
	return 0;

}
int main() {

	int T;
	scanf("%d", &T);

	while (T--){

		scanf("%d %d", &N, &M);
		getchar();
		for (int i = 0; i < N; i++)
			scanf("%s", map[i]);

		int len = dfs(0);
		if (len == 0) printf("XHAE\n");
		else {
			for (int i = 0; i < len; i++)
				printf("%c", A[ind[i]]);
			printf("\n");
		}

	}
	return 0;

}