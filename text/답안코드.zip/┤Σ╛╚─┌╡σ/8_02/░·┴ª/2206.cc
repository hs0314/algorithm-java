#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

queue < pair <int, int> > qu;
int N, M;
char map[1001][1001];
int d[2][1001][1001];

int qx[4] = {1, -1, 0, 0};
int qy[4] = {0, 0, 1, -1};

int main(){

	scanf("%d %d", &N, &M);
	getchar();

	for (int i = 0; i < N; i++)
		scanf("%s", map[i]);

	for (int i = 0; i < N; i++)
		for (int j = 0; j < M; j++)
			d[0][i][j] = d[1][i][j] = N * M + 1;

	qu.push(make_pair(0, 0));
	d[0][0][0] = 0;

	while (!qu.empty()){

		int x = qu.front().first, y = qu.front().second;
		qu.pop();

		for (int i = 0; i < 4; i++){
			int nx = x + qx[i], ny = y + qy[i];
			if (nx < 0 || nx >= N || ny < 0 || ny >= M) continue;

			if (map[nx][ny] == '0' && d[0][nx][ny] > d[0][x][y] + 1){
				d[0][nx][ny] = d[0][x][y] + 1;
				qu.push(make_pair(nx, ny));
			}

			if (map[nx][ny] == '0' && d[1][nx][ny] > d[1][x][y] + 1){
				d[1][nx][ny] = d[1][x][y] + 1;
				qu.push(make_pair(nx, ny));
			}

			if (map[nx][ny] == '1' && d[1][nx][ny] > d[0][x][y] + 1){
				d[1][nx][ny] = d[0][x][y] + 1;
				qu.push(make_pair(nx, ny));
			}
		}

	}

	if (min(d[0][N-1][M-1], d[1][N-1][M-1]) == N * M + 1) printf("-1");
	else printf("%d", min(d[0][N-1][M-1], d[1][N-1][M-1]) + 1);
	return 0;

}