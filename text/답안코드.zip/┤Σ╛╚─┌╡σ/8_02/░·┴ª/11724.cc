#include <stdio.h>
#include <vector>

using namespace std;

vector <int> v[1001];
int ind[1001];

void dfs(int s){

	for (int i = 0; i < v[s].size(); i++) {
		if (ind[v[s][i]] == 0) {
			ind[v[s][i]] = 1;
			dfs(v[s][i]);
		}
	}

}
int main(){

	int N, m;

	scanf("%d %d", &N, &m);

	for (int i = 0; i < m; i++){
		int x, y;
		scanf("%d %d", &x, &y);
		v[x - 1].push_back(y - 1);
		v[y - 1].push_back(x - 1);
	}

	int ans = 0;
	for (int i = 0; i < N; i++){
		if (ind[i] == 0){
			ans++;
			dfs(i);
		}
	}

	printf("%d", ans);
	return 0;

}