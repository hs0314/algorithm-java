#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

struct data {

	int rx, ry;
	int bx, by;

};

queue < struct data > qu;

int ind[11][11][11][11];
char map[11][11];
int qx[4] = {1, -1, 0, 0};
int qy[4] = {0, 0, 1, -1};

int N, M;
int endX, endY;

pair < struct data, int > run(int fx, int fy, int sx, int sy, int dir){

	int goal = 0;
	while (map[fx][fy] == '.')
		fx += qx[dir], fy += qy[dir];
	if (map[fx][fy] == 'O') goal = 1;
	else map[fx - qx[dir]][fy - qy[dir]] = '#';

	while (map[sx][sy] == '.')
		sx += qx[dir], sy += qy[dir];
	if (map[sx][sy] == 'O') goal |= 2;

	struct data last;

	map[fx - qx[dir]][fy - qy[dir]] = '.';
	last.rx = fx - qx[dir], last.ry = fy - qy[dir];
	last.bx = sx - qx[dir], last.by = sy - qy[dir];
	return make_pair(last, goal);

}
int main(){

	scanf("%d %d", &N, &M);
	for (int i = 0; i < N; i++)
		scanf("%s", map[i]);

	struct data start;
	for (int i = 0; i < N; i++){
		for (int j = 0; j < M; j++){
			if (map[i][j] == 'R'){
				start.rx = i, start.ry = j;
				map[i][j] = '.';
			}
			if (map[i][j] == 'B'){
				start.bx = i, start.by = j;
				map[i][j] = '.';
			}
			if (map[i][j] == 'O')
				endX = i, endY = j;
		}
	}

	qu.push(start);
	ind[start.rx][start.ry][start.bx][start.by] = 1;
	while (!qu.empty()){

		start = qu.front();
		int step = ind[start.rx][start.ry][start.bx][start.by];
		qu.pop();
        if (step > 10) continue;
        
		for (int i = 0; i < 4; i++){

			pair <struct data, int> end;
			if ((start.rx - start.bx) * qx[i] +
					(start.ry - start.by) * qy[i] > 0){
				end = run(start.rx, start.ry, start.bx, start.by, i);
			}else {
				end = run(start.bx, start.by, start.rx, start.ry, i);

				int temp = end.first.bx;
				end.first.bx = end.first.rx;
				end.first.rx = temp;

				temp = end.first.by;
				end.first.by = end.first.ry;
				end.first.ry = temp;
				end.second = ((end.second & 1) << 1) | ((end.second & 2) >> 1);
			}

			struct data ed = end.first;
			//printf("%d %d %d %d\n", ed.rx, ed.ry, ed.bx, ed.by);
			int goal = end.second;
			if (ind[ed.rx][ed.ry][ed.bx][ed.by] == 0 && goal == 0){
				ind[ed.rx][ed.ry][ed.bx][ed.by] = step + 1;
				qu.push(ed);
			}else if (goal == 1){
				printf("%d\n", step);
				return 0;
			}

		}

	}
	printf("-1\n");
	return 0;

}