#include <stdio.h>

int ind[30], ans = 1;
int qx[5] = {0, 0, 1, -1};
int qy[5] = {1, -1, 0, 0};
char q[22][22];

void dfs(int x, int y, int count){

	int i;
	for (i = 0; i < 4; i++){
	
		if (q[x + qx[i]][y + qy[i]] < 'A') continue;
		if (ind[q[x + qx[i]][y + qy[i]] - 'A'] == 0){
		
			ind[q[x + qx[i]][y + qy[i]] - 'A'] = 1;
			dfs(x + qx[i], y + qy[i], count + 1);
			ind[q[x + qx[i]][y + qy[i]] - 'A'] = 0;

		}
	
	}
	if (ans < count) ans = count;

}
int main(){

	int n, m, i, j;
	scanf("%d %d", &n, &m);

	for (i = 1; i <= n; i++){

		getchar();	
		for (j = 1; j <= m; j++){
		
			scanf("%c", &q[i][j]);
		
		}
	
	}

	ind[q[1][1] - 'A'] = 1;
	dfs(1, 1, 1);

	printf("%d", ans);
	return 0;
	
}