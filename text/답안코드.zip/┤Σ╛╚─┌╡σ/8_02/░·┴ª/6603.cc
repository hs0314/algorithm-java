#include <stdio.h>

int ind[20], q[20];
int N;

void back(int len, int s){

	if (len == 6) {
		for (int i = 0; i < 6; i++)
			printf("%d ", ind[i]);
		printf("\n");
		return;
	}

	for (int i = s; i < N; i++){
		ind[len] = q[i];
		back(len + 1, i + 1);
	}

}
int main(){

	while (1){

		scanf("%d", &N);
		if (N == 0) return 0;

		for (int i = 0; i < N; i++)
			scanf("%d", &q[i]);

		back(0, 0);
		printf("\n");

	}
    
}