#include <stdio.h>
#include <deque>
#include <algorithm>

using namespace std;

deque < pair<int, int> > dq;

int map[110][110];
int ch = 0, T = 0;
int qx[5] = {0, 0, 1, -1};
int qy[5] = {1, -1, 0, 0};
int v[110][110];

void fl(){

	dq.push_back(make_pair(1, 1));

	int k;
	while (!dq.empty()){
	
		int x = dq.front().first, y = dq.front().second;
		dq.pop_front();	
		for (k = 0; k < 4; k++){
		
			if (map[x + qx[k]][y + qy[k]] == 0 && v[x + qx[k]][y + qy[k]] == 0){
			
				dq.push_back(make_pair(x + qx[k], y + qy[k]));
				v[x + qx[k]][y + qy[k]] = 1;
			
			}
			if (map[x + qx[k]][y + qy[k]] == 1)
				v[x + qx[k]][y + qy[k]] += 1;
		
		}
	
	}

}
int main(){

	int n, m, i, j;
	scanf("%d %d", &n, &m);

	for (i = 1; i <= n; i++){
		
		map[i][0] = -1;
		map[i][m + 1] = -1;
		for (j = 1; j <= m; j++){
			
			map[0][j] = -1;
			map[n + 1][j] = -1;
			scanf("%d", &map[i][j]);
			if (map[i][j] == 1) ch += 1;

		}
	
	}
	
	while (ch != 0){
	
		T += 1;
		fl();

		for (i = 1; i <= n; i++){
		
			for (j = 1; j <= m; j++){
			
				if (v[i][j] > 1) {
				
					map[i][j] = 0;
					ch -= 1;
				
				}
				v[i][j] = 0;
			
			}
		
		}

	}

	printf("%d", T);
	return 0;

}