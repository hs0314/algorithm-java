#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

queue < pair <int, int> > qu;

int q[111][111];
int ind[111][111];
int qx[5] = {1, -1, 0, 0};
int qy[5] = {0, 0, 1, -1};

int main(){

	int n, m;
	scanf("%d %d", &n, &m);

	int i, j;
	int cnt = 0, precnt = 0;

	for (i = 1; i <= n; i++){
		for (j = 1; j <= m; j++){
			scanf("%d", &q[i][j]);
			cnt += q[i][j];
		}
	}

	int ans = 0;
	while (1){
		ans += 1;
		qu.push(make_pair(1, 1));
		while (!qu.empty()){

			pair <int, int> cur = qu.front();
			qu.pop();

			for (i = 0; i < 4; i++){
				int xx = cur.first + qx[i], yy = cur.second + qy[i];
				if (xx < 1 || xx > n || yy < 1 || yy > m) continue;

				if (q[xx][yy] == 1){
					ind[xx][yy] = 2;
				}else if (ind[xx][yy] == 0){
					qu.push(make_pair(xx, yy));
					ind[xx][yy] = 1;
				}
			}

		}
		precnt = cnt;
		cnt = 0;
		//printf("\n");
		for (i = 1; i <= n; i++){
			for (j = 1; j <= m; j++){
				if (ind[i][j] == 2)
					q[i][j] = 0;
				ind[i][j] = 0;
				cnt += q[i][j];
				//printf("%d ", q[i][j]);
			}
			//printf("\n");
		}
		if (cnt == 0) break;
	}
	printf("%d\n%d", ans, precnt);

}