#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

queue < pair <int, int> > qu;

int N, M;
int qx[4] = {1, -1, 0, 0};
int qy[4] = {0, 0, 1, -1};
int map[301][301];
int ind[301][301];

int bfs(pair <int, int> s, int lv){

	int cnt = 0;
	queue < pair <int, int> > qq;
	qq.push(s);

	while (!qq.empty()){

		pair <int, int> temp = qq.front();
		qq.pop();

		for (int i = 0; i < 4; i++){
			int nx = temp.first + qx[i], ny = temp.second + qy[i];
			if (nx < 0 || nx >= N || ny < 0 || ny >= M) continue;

			if (map[nx][ny] != 0 && ind[nx][ny] != lv) {
				qq.push(make_pair(nx, ny));
				ind[nx][ny] = lv;
				cnt++;
			}
		}

	}

	return cnt;

}
queue < pair <int, int> > update(queue < pair <int, int> > st){

	queue < pair <int, int> > out, check;
	while (!st.empty()){

		pair <int, int> temp = st.front();
		st.pop();

		int cnt = 0;
		for (int i = 0; i < 4; i++){
			int nx = temp.first + qx[i], ny = temp.second + qy[i];
			if (nx < 0 || nx >= N || ny < 0 || ny >= M) continue;

			if (map[nx][ny] == 0) cnt++;
		}
		map[temp.first][temp.second] -= min(cnt, map[temp.first][temp.second]);
		if (map[temp.first][temp.second] != 0)
			out.push(temp);
		else{
			map[temp.first][temp.second] = 1;
			check.push(temp);
		}

	}

	while (!check.empty()){
		int x = check.front().first, y = check.front().second;
		check.pop();
		map[x][y] = 0;
	}

	return out;

}
int main(){

	scanf("%d %d", &N, &M);

	for (int i = 0; i < N; i++)
		for (int j = 0; j < M; j++){
			scanf("%d", &map[i][j]);
			if (map[i][j] != 0)
				qu.push(make_pair(i, j));
		}

	for (int ans = 0; ; ans++){

		int size = qu.size();
		if (size == 0) {
			printf("0");
			break;
		}

		if (bfs(qu.front(), ans + 1) != size) {
			printf("%d", ans);
			break;
		}

		qu = update(qu);
	}
    return 0;
    
}