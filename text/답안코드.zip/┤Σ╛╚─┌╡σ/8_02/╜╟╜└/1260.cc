#include <stdio.h>
#include <algorithm>
#include <queue>

using namespace std;

struct data{

	int x, y;

}q[21111];

int ind[1111];
int cnt[1111];
int n, m;
queue <int> dq;

bool comp(const data &a, const data &b){

	if (a.x < b.x)
		return true;
	else if (a.x == b.x)
		return a.y < b.y;
	
	return false;

}
void dfs(int s){

	ind[s] = 1;
	printf("%d ", s);
	int i;
	for (i = cnt[s - 1]; i < cnt[s]; i++){
		if (ind[q[i].y] == 0){
			dfs(q[i].y);
		}
	}

}
void bfs(int s){

	ind[s] = 0;
	dq.push(s);

	while (!dq.empty()){
	
		s = dq.front();
		dq.pop();
		printf("%d ", s);
		int i;
		for (i = cnt[s - 1]; i < cnt[s]; i++){
			if (ind[q[i].y] == 1){
				ind[q[i].y] = 0;
				dq.push(q[i].y);
			}
		}
		
	}

}
int main(){

	int s;
	int i, a, b;

	scanf("%d %d %d", &n, &m, &s);
	
	for (i = 0; i < m; i++){
	
		scanf("%d %d", &a, &b);
		q[i * 2].x = a;
		q[i * 2].y = b;
		q[i * 2 + 1].x = b;
		q[i * 2 + 1].y = a;
		cnt[a] += 1;
		cnt[b] += 1;

	}
	for (i = 1; i <= n; i++){
		cnt[i] += cnt[i - 1];	
	}
	sort(q, q + m * 2, comp);

	dfs(s);
	printf("\n");
	bfs(s);

}