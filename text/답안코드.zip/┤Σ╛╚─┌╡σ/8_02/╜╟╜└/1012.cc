#include <stdio.h>
#include <deque>
#include <algorithm>

using namespace std;

deque < pair <int, int> > dq;

int n, m, k, map[60][60];
int qx[5] = {0, 0, 1, -1};
int qy[5] = {1, -1, 0, 0};

int main(){

	int T;
	scanf("%d", &T);

	while (T--){
	
		int x, y;
		scanf("%d %d %d", &m, &n, &k);

		for (;k > 0; k--){
		
			scanf("%d %d", &x, &y);
			map[y + 1][x + 1] = 1;

		}

		int i, j, l, ans = 0;

		for (i = 1; i <= n; i++){
		
			for (j = 1; j <= m; j++){
			
				if (map[i][j] == 1){
				
					ans += 1;
					map[i][j] = 0;
					dq.push_back(make_pair(i, j));
					while (!dq.empty()){
					
						x = dq.front().first, y = dq.front().second;
						dq.pop_front();
						for (l = 0; l < 4; l++){
						
							if (map[x + qx[l]][y + qy[l]] == 1){
							
								map[x + qx[l]][y + qy[l]] = 0;
								dq.push_back(make_pair(x + qx[l], y + qy[l]));
							
							}
						
						}
					
					}
				
				}
			
			}

		}
	
		printf("%d\n", ans);

	}

	return 0;

}