#include<stdio.h>
  
typedef struct{
  short int vert;
 short int horiz;
}offsets;
  
typedef struct{
 short int  row;
 short int col;
 short int dir;
}element;
  
int maze[102][102];
int mark[102][102];
element my;
offsets move[4];
int ans;
int maxRow,maxCol;
element trace[10000000];
void bfs();
  
int main()
{
int row,col;
int nextRow,nextCol;
int i,j;
char temp;
int ans;
  
move[3].vert = -1;
move[3].horiz = 0;// 북 0,-1
  
move[0].horiz = 1;
move[0].vert = 0;//동 1,0
  
move[1].vert = 1;
move[1].horiz = 0;//남 0,1
  
move[2].horiz = -1;
move[2].vert = 0;// 서 -1.0
  
//방향에 따른 이동 0 :북 1: 동 2: 남 3: 서
   
  
 scanf("%d %d",&maxRow,&maxCol);
  
 for(i=0;i<=maxRow+1;i++)
 {
  maze[i][0] = 0;
  maze[i][maxCol+1]=0;
    
 }
 for(i=0;i<=maxCol+1;i++)
 {
  maze[0][i] = 0;
  maze[maxRow+1][i] =0;
 }
  
 for(i=0;i<=maxRow+1;i++)
 {
  for(j=0;j<=maxCol+1;j++)
  {
   mark[i][j]=0;
  }
 }
  
   
     
 getchar();
 for(i=1;i<=maxRow;i++)
 {
  for(j=1;j<=maxCol;j++)
  { scanf("%c",&temp);
   maze[i][j]=(int)temp-'0';
   }
  getchar();
 }
 bfs();
 printf("%d\n",mark[maxRow][maxCol]+1);
   
 return 0;
}
  
  
void bfs()
{
    int i,j;
    int head,tail;
    head = tail = 0;
    trace[head].row = 1;
    trace[head].col = 1;
  
    while(1)
    {
        for(i=0;i<4;i++)
        {
              
            if(maze[trace[head].row+move[i].horiz][trace[head].col+move[i].vert] == 1)
            {
                if(mark[trace[head].row+move[i].horiz][trace[head].col+move[i].vert]==0){
                tail = tail+1;
                trace[tail].row=trace[head].row+move[i].horiz;
                trace[tail].col=trace[head].col+move[i].vert;
                mark[trace[tail].row][trace[tail].col]=mark[trace[head].row][trace[head].col]+1;
                }
            }
            maze[trace[head].row][trace[head].col]=0;
  
        }
        if(head==tail) break;
        head=head+1;
    } 
      
}