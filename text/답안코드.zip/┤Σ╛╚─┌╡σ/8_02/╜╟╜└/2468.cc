#include <stdio.h>
#include <algorithm>
#include <deque>

using namespace std;

deque < pair<int, int> > dq;

int qx[5] = {0, 0, 1, -1};
int qy[5] = {-1, 1, 0, 0};
int cnt, q[111][111], ind[111][111], ans = 1;

int main(){

	int n, i, j, k, T;

	scanf("%d", &n);

	for (i = 1; i <= n; i++){

		for (j = 1; j <= n; j++){

			scanf("%d", &q[i][j]);

		}

	}

	for (T = 1; T <= 100; T++){
		
		cnt = 0;
		for (i = 1; i <= n; i++){

			for (j = 1; j <= n; j++){

				if (ind[i][j] == 0 && q[i][j] > T){
					
					cnt += 1;
					//bfs
					dq.push_back(make_pair(i, j));
					ind[i][j] = cnt;

					while (dq.size()){
					
						int x = dq.front().first;
						int y = dq.front().second;

						dq.pop_front();

						for (k = 0; k < 4; k++){
						
							if (q[x + qx[k]][y + qy[k]] > T && ind[x + qx[k]][y + qy[k]] == 0){
							
								ind[x + qx[k]][y + qy[k]] = cnt;
								dq.push_back(make_pair(x + qx[k], y + qy[k]));
								
							}
						
						}
					
					}
				
				}

			}

		}

		for (i = 1; i <= n; i++){
		
			for (j = 1; j <= n; j++){
			
				ind[i][j] = 0;
			
			}
		
		}

		if (ans < cnt) ans = cnt;

	}

	printf("%d", ans);

}