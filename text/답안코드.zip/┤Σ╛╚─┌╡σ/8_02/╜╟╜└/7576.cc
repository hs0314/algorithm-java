#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector < pair<int, int> > v, nv;
int q[1100][1100];
int qx[5] = {0,0,1,-1};
int qy[5] = {1,-1,0,0};

int main(){

	int n, m, i, j, zero = 0;

	scanf("%d %d", &m, &n);

	for (i = 1; i <= n; i++){
	
		for (j = 1; j <= m; j++){
		
			scanf("%d", &q[i][j]);
			if (q[i][j] == 1) v.push_back(make_pair(i, j));
			if (!q[i][j]) zero += 1;	

		}
	
	}
	
	int time = 0;
	while (v.size()){
	
		int end = v.size();

		for (i = 0; i < end; i++){
		
			for (j = 0; j < 4; j++){
			
				int x = v[i].first + qx[j], y = v[i].second + qy[j];
				if (q[x][y] == 0 && x > 0 && n >= x && y > 0 && m >= y){
				
					q[x][y] = 1;
					nv.push_back(make_pair(x, y));
					zero -= 1;

				}
			
			}
		
		}
		v = nv;
		nv.clear();
		time += 1;
	
	}

	if (zero == 0) printf("%d", time - 1);
	else printf("-1");
	
	return 0;

}