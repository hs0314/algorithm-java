#include <stdio.h>
#include <algorithm>
#include <queue>

using namespace std;

int N;
int map[101][101];
int ind[101][101];
int qx[4] = {1, -1, 0, 0};
int qy[4] = {0, 0, 1, -1};

void bfs(pair <int, int> st, int tag){

	queue < pair <int, int> > qu;
	qu.push(st);

	while (!qu.empty()){

		st = qu.front();
		int x = st.first, y = st.second;
		qu.pop();

		for (int i = 0; i < 4; i++){

			int nx = x + qx[i], ny = y + qy[i];
			if (nx < 0 || nx >= N || ny < 0 || ny >= N) continue;

			if ((map[nx][ny] & tag) && ind[nx][ny] != tag){
				qu.push(make_pair(nx, ny));
				ind[nx][ny] = tag;
			}

		}

	}

}
int solve(int tag){

	int ans = 0;
	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			if (ind[i][j] != tag && (map[i][j] & tag)){
				ans++;
				bfs(make_pair(i, j), tag);
			}

	return ans;

}
int main(){

	scanf("%d", &N);
	getchar();

	char a;

	for (int i = 0; i < N; i++){
		for (int j = 0; j < N; j++){
			scanf("%c", &a);
			if (a == 'R') map[i][j] = 1;
			if (a == 'G') map[i][j] = 2;
			if (a == 'B') map[i][j] = 4;
		}
		getchar();
	}

	int R = solve(1);
	int G = solve(2);
	int B = solve(4);
	int RG = solve(3);

	printf("%d %d", R + G + B, RG + B);
	return 0;

}