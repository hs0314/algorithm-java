#include <stdio.h>

int a[111];

void hanoi(int n, int a, int b, int c){

	if (n == 0)
		return;

	hanoi(n - 1, a, c, b);
	printf("%c %c\n", a, c);
	hanoi(n - 1, b, a, c);

}
int main(){

	int N, len = 1;
	scanf("%d", &N);

	a[0] = 1;
	for (int i = 0; i < N; i++){
		for (int j = len - 1; j >= 0; j--){
			a[j + 1] += (a[j] * 2) / 10;
			a[j] = (a[j] * 2) % 10;
		}
		if (a[len] != 0) len += 1;
	}

	a[0]--;
	for (int j = len - 1; j >= 0; j--) printf("%d", a[j]);
	printf("\n");

	if (N <= 20)
		hanoi(N, '1', '2', '3');

	return 0;

}