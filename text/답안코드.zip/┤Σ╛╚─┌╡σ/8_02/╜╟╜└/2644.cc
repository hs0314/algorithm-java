#include <stdio.h>
#include <vector>

using namespace std;

vector <int> v[101];
int S, E;
int ind[101];

int dfs(int s, int lv){

	ind[s] = 1;
	if (s == E)
		return lv;

	for (int i = 0; i < v[s].size(); i++){

		int next = v[s][i];
		if (ind[next] == 0){
			int temp = dfs(next, lv + 1);
			if (temp != -1)
				return temp;
		}

	}

	ind[s] = 0;
	return -1;

}
int main(){

	int n, m;
	scanf("%d", &n);
	scanf("%d %d", &S, &E);
	scanf("%d", &m);

	for (int i = 0; i < m; i++){
		int x, y;
		scanf("%d %d", &x, &y);
		v[x].push_back(y);
		v[y].push_back(x);
	}

	printf("%d", dfs(S, 0));
	return 0;

}