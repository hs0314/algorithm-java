#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

queue < pair <int, int> > qu;
int N, M;
// N, M <= 8;
// The number of wall which we have to make is 3
// (8*8) * (8*8) * (8*8)
int map[9][9];
int visit[9][9];
int qx[4] = {-1, 1, 0, 0};
int qy[4] = {0, 0, -1, 1};

int bfs(queue < pair <int, int> > start, int l){

	int filled = 0;
	while (!start.empty()){

		pair <int, int> temp = start.front();
		int sx = temp.first, sy = temp.second;
		start.pop();

		for (int i = 0; i < 4; i++){

			int nx = sx + qx[i], ny = sy + qy[i];
			if (nx < 0 || nx >= N || ny < 0 || ny >= M) continue;

			if (visit[nx][ny] != -1 && visit[nx][ny] != l){
				visit[nx][ny] = l;
				filled += 1;
				start.push(make_pair(nx, ny));
			}

		}

	}

	return filled;

}
int main(){

	int base = 0;
	scanf("%d %d", &N, &M);

	for (int i = 0; i < N; i++)
		for (int j = 0; j < M; j++){
			scanf("%d", &map[i][j]);
			if (map[i][j] == 2){
				qu.push(make_pair(i, j));
				visit[i][j] = -1;
			}
			if (map[i][j] == 1)
				visit[i][j] = -1;
			if (map[i][j] == 0)
				base += 1;
		}

	int l = 1;
	int ans = 0;

	for (int i = 0; i < N*M; i++)
		for (int j = i + 1; j < N*M; j++)
			for (int k = j + 1; k < N*M; k++){
				int X1 = i / M, Y1 = i % M;
				int X2 = j / M, Y2 = j % M;
				int X3 = k / M, Y3 = k % M;
				if ((visit[X1][Y1] + 1)	* (visit[X2][Y2] + 1) * (visit[X3][Y3] + 1) == 0) continue;
				visit[X1][Y1] = visit[X2][Y2] = visit[X3][Y3] = -1;

				int temp = base - bfs(qu, l++) - 3;
				ans = max(temp, ans);

				visit[X1][Y1] = visit[X2][Y2] = visit[X3][Y3] = 0;
			}

	printf("%d", ans);
    return 0;
    
}