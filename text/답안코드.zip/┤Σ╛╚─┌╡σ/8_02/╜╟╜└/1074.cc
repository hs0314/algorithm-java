#include <stdio.h>
#include <math.h>

int r, c;
void back(int x, int y, int size, int count){

	if (size == 0) {
		printf("%d\n", count);
		return;
	}
	/*
	1 2
	3 4
	*/
	//1
	if (x + size > r && y + size > c)
		back(x, y, size / 2, count);
	else if (x + size > r && y + size <= c)
		back(x, y + size, size / 2, count + size*size);
	else if (x + size <= r && y + size > c)
		back(x + size, y, size / 2, count + size*size*2);
	else
		back(x + size, y + size, size / 2, count + size*size*3);

}
int main(){

	int n;
	while (scanf("%d %d %d", &n, &r, &c) != EOF){
	
		back(0, 0, pow((double)2, n - 1), 0);
	
	}
	return 0;

}