#include <stdio.h>

int d[11111];
int main(){

	int n, k, i, j, cost;

	scanf("%d %d", &n, &k);
	
	d[0] = 1;

	for (i = 1; i <= n; i++){
	
		scanf("%d", &cost);

		for (j = cost; j <= k; j++){
		
			d[j] += d[j - cost];
		
		}
	
	}

	printf("%d", d[k]);

}