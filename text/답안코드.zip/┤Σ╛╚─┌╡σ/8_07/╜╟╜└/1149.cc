#include <stdio.h>

int q[4][1100];

int min(int a, int b){
	
	if (a < b) return a;
	return b;

}
int main(){

	int n, i;
	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		scanf("%d %d %d", &q[1][i], &q[2][i], &q[3][i]);

	}

	for (i = 2; i <= n; i++){
	
		q[1][i] += min(q[2][i - 1], q[3][i - 1]);
		q[2][i] += min(q[1][i - 1], q[3][i - 1]);
		q[3][i] += min(q[1][i - 1], q[2][i - 1]);
	
	}
	
	printf("%d", min(min(q[1][n], q[2][n]), q[3][n]));
	return 0;

}