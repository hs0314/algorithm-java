#include <stdio.h>

int q[400];
int d[400][5];

int max(int a, int b){

	return a > b?a : b;

}
int main(){

	int n, i;

	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		scanf("%d", &q[i]);
	
	}

	d[1][1] = q[1];
	d[2][1] = q[2];
	d[2][2] = q[2] + q[1];

	for (i = 3; i <= n; i++){
	
		d[i][1] = max(d[i - 2][1], d[i - 2][2]) + q[i];
		d[i][2] = d[i - 1][1] + q[i];
	
	}

	printf("%d", max(d[n][1], d[n][2]));

}