#include <stdio.h>

int q[10010];
int d[10010][4];

int max(int a, int b){

	if (a > b) return a;
	return b;

}
int main(){

	int n, i;
	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		scanf("%d", &q[i]);
	
	}

	d[1][0] = 0;
	d[1][1] = q[1];
	d[1][2] = 0;
	for (i = 2; i <= n; i++){
	
		d[i][0] = max(d[i - 1][2], max(d[i - 1][1], d[i - 1][0]));
		d[i][1] = q[i] + d[i - 1][0];
		d[i][2] = q[i] + d[i - 1][1];
	
	}

	printf("%d", max(d[n][0], max(d[n][1], d[n][2])));

	return 0;

}