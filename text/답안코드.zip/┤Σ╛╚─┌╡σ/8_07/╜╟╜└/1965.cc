#include <stdio.h>

int d[1100][3];
int ans;

int max(int a, int b){

	return a>b?a:b;

}
int main(){

	int i, n, j;

	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		scanf("%d", &d[i][0]);
	
	}

	for (i = 1; i <= n; i++){
	
		d[i][1] = 1;
		for (j = 1; j < i; j++){
		
			if (d[i][0] > d[j][0]){
			
				d[i][1] = max(d[i][1], d[j][1] + 1);
			
			}
		
		}

		ans = max(ans, d[i][1]);
	
	}

	printf("%d", ans);

}