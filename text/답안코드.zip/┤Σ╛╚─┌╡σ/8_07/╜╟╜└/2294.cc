#include <stdio.h>
#include <algorithm>

using namespace std;

int cost[110];
int d[11111];

int main(){

	int n, k;
	scanf("%d %d", &n, &k);

	int i, j;

	for (i = 1; i <= n; i++){
	
		scanf("%d", &cost[i]);
	
	}

	sort(cost + 1, cost + 1 + n);
	
	for (i = 1; i <= k; i++) d[i] = 999999999;
	d[0] = 0;

	for (i = 1; i <= n; i++){
	
		for (j = cost[i]; j <= k; j++){
		
			d[j] = min(d[j], d[j - cost[i]] + 1);
		
		}
	
	}
    
    if (d[k] == 999999999) printf("-1");
	else printf("%d", d[k]);
	return 0;

}