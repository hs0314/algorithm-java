#include <stdio.h>

int q[201];
int d[201];

int main(){

	int n;

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &q[i]);

	int ans = 0;

	for (int i = 0; i < n; i++){
		d[i] = 1;
		for (int j = 0; j < i; j++)
			if (d[i] < d[j] + 1 && q[i] > q[j])
				d[i] = d[j] + 1;
		if (ans < d[i]) ans = d[i];
	}
	printf("%d", n - ans);
	return 0;

}