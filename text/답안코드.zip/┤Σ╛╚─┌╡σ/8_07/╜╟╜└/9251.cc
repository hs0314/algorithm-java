#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
 
int d[2000][2000]={0,};
int main()
{
    char s[2000];
    char t[2000];
    scanf("%s", s);
    scanf("%s", t);
    int lengs=strlen(s);
    int lengt=strlen(t);
     
    for(int i=1; i<=lengs; i++){
        for(int j=1; j<=lengt; j++){
            if(s[i-1]==t[j-1]){
                d[i][j]=d[i-1][j-1]+1;
            }
            else{
                d[i][j]=max(d[i][j-1],d[i-1][j]);
            }
         
        }
    }
    printf("%d", d[lengs][lengt]);
    return 0;
}