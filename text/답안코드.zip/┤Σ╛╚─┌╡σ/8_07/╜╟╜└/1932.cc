#include <stdio.h>

int table[555][555], ans = 0;

int max(int a, int b){
	
	if (a > b) return a;
	return b;

}
int main(){

	int n;
	int i, j;

	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		for (j = 1; j <= i; j++){
		
			int a;
			scanf("%d", &a);
			table[i][j] = max(table[i - 1][j - 1] + a, table[i - 1][j] + a);
			ans = max(ans, table[i][j]);
		
		}

	}

	printf("%d", ans);
	return 0;

}