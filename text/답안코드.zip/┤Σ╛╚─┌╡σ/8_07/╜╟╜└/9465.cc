#include <stdio.h>
#include <algorithm>

using namespace std;

int first[100001];
int second[100001];
int d[2][100001];

int main(){

	int T, n;
	scanf("%d", &T);

	while (T--){

		scanf("%d", &n);
		for (int i = 0; i < n; i++)
			scanf("%d", &first[i]);
		for (int i = 0; i < n; i++)
			scanf("%d", &second[i]);

		d[0][0] = first[0];
		d[1][0] = second[0];
		d[0][1] = second[0] + first[1];
		d[1][1] = first[0] + second[1];

		for (int i = 2; i < n; i++){
			d[0][i] = max(d[1][i - 1], d[1][i - 2]) + first[i];
			d[1][i] = max(d[0][i - 1], d[0][i - 2]) + second[i];
		}

		printf("%d\n", max(d[0][n - 1], d[1][n - 1]));

	}
    return 0;

}