#include <stdio.h>

int T[16];
int P[16];
int d[16];

int main(){

	int N;
	scanf("%d", &N);

	for (int i = 0; i < N; i++)
		scanf("%d %d", &T[i], &P[i]);

	for (int i = 0; i < N; i++){

		if (T[i] + i - 1 < N)
			d[i] = P[i];

		int max = -1, temp = -1;
		for (int j = 0; j < i; j++)
			if (i > T[j] + j - 1 && max < d[j])
				max = d[j], temp = j;

		if (temp != -1)
			d[i] += d[temp];

	}

	int ans = 0;
	for (int i = 0; i < N; i++)
		if (ans < d[i]) ans = d[i];
	printf("%d", ans);
    return 0;

}