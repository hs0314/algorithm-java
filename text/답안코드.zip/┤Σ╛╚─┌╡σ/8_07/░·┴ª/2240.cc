#include <stdio.h>
#include <algorithm>

using namespace std;

int d[31][1001];
int q[1001];

int main(){

	int T, W;
	scanf("%d %d", &T, &W);

	for (int i = 0; i < T; i++){
		scanf("%d", &q[i]);
		if (i == 0) d[0][0] = q[i] % 2;
		else d[0][i] = d[0][i - 1] + q[i] % 2;
	}

	d[1][0] = 1;

	for (int i = 1; i <= W; i++)
		for (int j = 1; j < T; j++){
			int tag = 0;
			if (q[j] == i % 2 + 1) tag = 1;
			d[i][j] = max(d[i - 1][j], max(d[i - 1][j - 1], d[i][j - 1]) + tag);
		}

	printf("%d", d[W][T-1]);
	return 0;

}