#include <stdio.h>
#include <algorithm>

using namespace std;

int q[111111];
int ind[111111];

int back(int l, int r, int k){

	if (l > r) return l;
	int t = (l + r) / 2;

	if (ind[t] < k)
		back(t + 1, r, k);
	else 
		back(l, t - 1, k);

}

int main(){

	int n;
	scanf("%d", &n);

	int i;
	for (i = 1; i <= n; i++){
		scanf("%d", &q[i]);
	}

	int last = 1;
	ind[1] = q[1];

	for (i = 2; i <= n; i++){
		int cc = back(1, last, q[i]);
		ind[cc] = q[i];
		if (last < cc) last = cc;
	}
	
	printf("%d\n", n - last);
	
}