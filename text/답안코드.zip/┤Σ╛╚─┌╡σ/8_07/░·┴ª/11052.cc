#include <stdio.h>
#include <algorithm>

using namespace std;

int N;
int P[1001];
int d[1001];

int main(){

	scanf("%d", &N);

	for (int i = 0; i < N; i++)
		scanf("%d", &P[i]);

	d[0] = 0;
	for (int i = 1; i <= N; i++)
		for (int j = i; j <= N; j++)
			d[j] = max(d[j], d[j - i] + P[i - 1]);

	printf("%d", d[N]);
	return 0;

}