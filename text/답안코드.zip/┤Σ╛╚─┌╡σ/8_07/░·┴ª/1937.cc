#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

priority_queue < int, vector <int>, greater <int> > pq;

int n;
int map[501][501];
int ind[501][501];
int d[501][501];
int qx[4] = {1, -1, 0, 0};
int qy[4] = {0, 0, 1, -1};

int main(){

	scanf("%d", &n);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &map[i][j]);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++){

			ind[i][j] = 0;
			for (int k = 0; k < 4; k++){
				int nx = i + qx[k];
				int ny = j + qy[k];

				if (nx < 0 || nx >= n || ny < 0 || ny >= n) continue;

				if (map[nx][ny] < map[i][j]) ind[i][j] += 1;
			}
			if (ind[i][j] == 0){
				pq.push(i * n + j);
				d[i][j] = 1;
			}

		}

	int ans = 1;
	while (!pq.empty()){

		int temp = pq.top();
		pq.pop();
		int x = temp / n, y = temp % n;

		for (int i = 0; i < 4; i++){
			int nx = x + qx[i], ny = y + qy[i];
			if (nx < 0 || nx >= n || ny < 0 || ny >= n) continue;

			if (map[x][y] < map[nx][ny]) {
				ind[nx][ny] -= 1;
				if (d[nx][ny] < d[x][y] + 1)
					d[nx][ny] = d[x][y] + 1;
				if (ind[nx][ny] == 0){
					if (ans < d[nx][ny]) ans = d[nx][ny];
					pq.push(nx * n + ny);
				}
			}
		}

	}
	printf("%d", ans);
    return 0;

}