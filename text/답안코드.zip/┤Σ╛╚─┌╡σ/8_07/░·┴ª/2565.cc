#include <stdio.h>
#include <algorithm>

using namespace std;

struct data{

	int a, b;

}q[111];

int ind[111];

bool comp(data a, data b){

	return a.a < b.a;

}
int main(){

	int n, i;
	scanf("%d", &n);

	for (i = 1; i <= n; i++)
		scanf("%d %d", &q[i].a, &q[i].b);

	sort(q + 1, q + 1 + n, comp);

	int max = 0, j;
	for (i = 1; i <= n; i++){
	
		ind[i] = 1;
		for (j = i - 1; j >= 1; j--){
			if (q[j].b < q[i].b && ind[i] < ind[j] + 1){
				ind[i] = ind[j] + 1;
			}
		}
	
		if (max < ind[i]) max = ind[i];

	}
	printf("%d", n - max);
	return 0;

}