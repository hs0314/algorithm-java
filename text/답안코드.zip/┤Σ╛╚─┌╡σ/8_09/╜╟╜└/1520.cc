#include <stdio.h>
#include <queue>
#include <algorithm>

using namespace std;

priority_queue < pair < int, pair <int, int> > > pq;

int qx[4] = {-1, 1, 0, 0};
int qy[4] = {0, 0, -1, 1};
int q[555][555];
int d[555][555];

int main(){

	int n, m;
	scanf("%d %d", &n, &m);
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++){
			scanf("%d", &q[i][j]);
			d[i][j] = 0;
		}

	pq.push(make_pair(q[0][0], make_pair(0, 0)));
	d[0][0] = 1;

	while (!pq.empty()){
		
		int x = pq.top().second.first;
		int y = pq.top().second.second;
		if (x == n - 1 && y == m - 1) break;
		pq.pop();
		
		if (q[x][y] == 100000) continue;
		
		for (int i = 0; i < 4; i++){
			int nx = x + qx[i], ny = y + qy[i];
			if (nx < 0 || nx >= n || ny < 0 || ny >= m) continue;
			if (q[x][y] > q[nx][ny]) {
				d[nx][ny] += d[x][y];
				pq.push(make_pair(q[nx][ny], make_pair(nx, ny)));
			}
		}	
		q[x][y] = 100000;

	}
	printf("%d", d[n-1][m-1]);
	return 0;

}
