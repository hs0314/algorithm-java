#include <stdio.h>

int d[111];
int main(){

	int i;
	int n;

	scanf("%d", &n);
	
	d[0] = 1;
	for (i = 1; i <= n; i++){
	
		if (i % 2 == 0)
			d[i] = d[i - 1] + d[i - 2];
		else 
			d[i] = d[i - 1] * 2 + d[i - 2];

	}
	if (n % 2 != 0) printf("0");
	else printf("%d", d[n]);

}