#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

int d[1111][22];

vector <int> loca[11];

int main (){

	int i, j, k;

	loca[1].push_back(2), loca[1].push_back(4);
	loca[2].push_back(1), loca[2].push_back(3), loca[2].push_back(5);
	loca[3].push_back(2), loca[3].push_back(6);
	loca[4].push_back(1), loca[4].push_back(5), loca[4].push_back(7);
	loca[5].push_back(2), loca[5].push_back(4), loca[5].push_back(6), loca[5].push_back(8);
	loca[6].push_back(3), loca[6].push_back(5), loca[6].push_back(9);
	loca[7].push_back(4), loca[7].push_back(8), loca[7].push_back(0);
	loca[8].push_back(9), loca[8].push_back(5), loca[8].push_back(7);
	loca[9].push_back(8), loca[9].push_back(6);
	loca[0].push_back(7);
	
	for (i = 0; i <= 9; i++)
		d[1][i] = 1;

	for (i = 2; i <= 1000; i++){
	
		for (j = 0; j <= 9; j++){
		
			for (k = 0; k < loca[j].size(); k++){
			
				d[i][j] += d[i - 1][loca[j][k]];
				d[i][j] %= 1234567;
			
			}
		
		}
	
	}

	int T, n;
	scanf("%d", &T);

	while (T--){
	
		scanf("%d", &n);
		
		int sum = 0;

		for (i = 0; i <= 9; i++){
		
			sum += d[n][i];
			sum %= 1234567;
		
		}

		printf("%d\n", sum);
	
	}

}