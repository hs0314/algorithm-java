#include <stdio.h>
#define mod 1000000007

int d[5100][5100];

int min(int a, int b){
	return a < b? a: b;
}
int main(){

	int T;
	scanf("%d", &T);

	d[1][1] = 1;
	for (int i = 2; i <= 5000; i++){
		for (int j = min(2500, i - 1); j >= 0; j--){
			d[i][j + 1] += d[i - 1][j];
			d[i][j + 1] %= mod;
			if (j - 1 >= 0) d[i][j - 1] += d[i - 1][j];
			d[i][j - 1] %= mod;
		}
	}

	while (T--){
		int n;
		scanf("%d", &n);
		printf("%d\n", d[n][0]);
	}
	return 0;

}