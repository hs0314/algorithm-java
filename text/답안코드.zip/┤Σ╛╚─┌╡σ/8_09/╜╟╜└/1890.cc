#include <stdio.h>

long long d[110][110];
long long q[110][110];

int main(){

	int n, i, j, k;
	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		for (j = 1; j <= n; j++){
		
			scanf("%lld", &q[i][j]);
		
		}
	
	}

	d[1][1] = 1;
	for (i = 1; i <= n; i++){
	
		for (j = 1; j <= n; j++){
		
			for (k = 1; k < i; k++){
			
				if (q[k][j] + k == i){
				
					d[i][j] += d[k][j];

				}

			}
			for (k = 1; k < j; k++){
			
				if (q[i][k] + k == j){
				
					d[i][j] += d[i][k];
				
				}
			
			}
		
		}
	
	}

	printf("%lld", d[n][n]);
	return 0;

}