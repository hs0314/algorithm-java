#include <stdio.h>

int n;
long long table[4][1004];
int main(){
	
	scanf("%d", &n);
	
	int i = 0, j = 0;

	table[0][0] = 1;

	for (i = 1; i <= n; i++){
	
		table[0][i] = table[0][i - 1] + table[1][i - 1] + table[2][i - 1];
		table[1][i] = table[0][i - 1];
		table[2][i] = table[1][i - 1];
	
		table[0][i] %= 1000000;
		table[1][i] %= 1000000;
		table[2][i] %= 1000000;

	}

	long long ans = table[0][n] + table[1][n] + table[2][n];
	table[0][n + 1] = table[0][n] + table[1][n] + table[2][n];

	for (i = 0; i <= n - 1; i++){
	
		ans += table[0][i + 1] * table[0][n - i];
		ans %= 1000000;

	}

	printf("%d\n", ans);
	
	return 0;

}