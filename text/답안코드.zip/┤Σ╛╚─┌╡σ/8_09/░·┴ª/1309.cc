#include <stdio.h>
#include <string.h>

char str[1001];

int main(){

	scanf("%s", str);

	int n = strlen(str);
	int ans = 0;

	for (int i = 1; i <= n; i++){
		int s, e;
		for (s = n - i, e = n - 1; s < e; s++, e--)
			if (str[s] != str[e])
				break;
		if (s >= e) ans = i;
	}

	printf("%d", n - ans + n);
	return 0;

}