#include <stdio.h>
#include <algorithm>

using namespace std;

char str[5001];
int d[5001][5001];

int back(int s, int e){
	
	if (d[s][e] != 0)
		return d[s][e];
	if (s > e)
		return 0;
	if (s == e)
		return 1;

	int ans = 0;
	if (str[s] == str[e]){
		ans = back(s + 1, e - 1) + 2;
	}
	ans = max(ans, back(s, e - 1));
	ans = max(ans, back(s + 1, e));
	d[s][e] = ans;
	
	return ans;

}
int main(){

	int n;
	scanf("%d", &n);
	scanf("%s", str);
	
	printf("%d", n - back(0, n - 1));
	return 0;

}
