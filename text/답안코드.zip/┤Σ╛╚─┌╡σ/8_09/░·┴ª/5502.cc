#include <stdio.h>
#include <algorithm>

using namespace std;

int maxd[100001][3];
int mind[100001][3];

int main(){

	int N;
	scanf("%d", &N);
	
	//init
	maxd[0][0] = maxd[0][1] = maxd[0][2] = 0;
	mind[0][0] = mind[0][1] = mind[0][2] = 0;
	
	for (int i = 1; i <= N; i++){
		int x, y, z;
		scanf("%d %d %d", &x, &y, &z);
		
		//dp formula
		maxd[i][0] = max(maxd[i - 1][0], maxd[i - 1][1]) + x;
		maxd[i][1] = max(maxd[i - 1][0], max(maxd[i - 1][2], maxd[i - 1][1])) + y;
		maxd[i][2] = max(maxd[i - 1][1], maxd[i - 1][2]) + z;
		
		mind[i][0] = min(mind[i - 1][0], mind[i - 1][1]) + x;
		mind[i][1] = min(mind[i - 1][0], min(mind[i - 1][2], mind[i - 1][1])) + y;
		mind[i][2] = min(mind[i - 1][1], mind[i - 1][2]) + z;		
	}

	printf("%d ", max(maxd[N][0], max(maxd[N][1], maxd[N][2])));
	printf("%d", min(mind[N][0], min(mind[N][1], mind[N][2])));
	return 0;

}
