#include <stdio.h>
#include <algorithm>

using namespace std;

int d[1001];
int q[1001];

int main(){

	int N;
	scanf("%d", &N);

	for (int i = 0; i < N; i++)
		scanf("%d", &q[i]);
	
	int ans = 0;
	for (int i = 0; i < N; i++){
	
		d[i] = 1;
		for (int j = 0; j < i; j++)
			if (q[i] < q[j] && d[i] < d[j] + 1)
				d[i] = d[j] + 1;
		ans = max(d[i], ans);
	
	}

	printf("%d", ans);
	return 0;

}
