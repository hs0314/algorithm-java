#include <stdio.h>
#include <queue>
#include <vector>
#include <algorithm>

using namespace std;

priority_queue < pair<int, int>, vector < pair<int, int> >, greater < pair<int, int> > > q;
vector <pair <int, int> > a[211111];

int d[211111];

int main(){

	int n, m;

	scanf("%d %d", &n, &m);

	int k;
	scanf("%d", &k);

	for (int i = 1; i <= n; i++)
		d[i] = 2100000000;

	for (int i = 0; i < m; i++){
		int x, y, z;
		scanf("%d %d %d", &x, &y, &z);
		a[x].push_back(make_pair(y, z));
	}

	d[k] = 0;
	q.push(make_pair(d[k], k));

	while (!q.empty()){
		int cost = q.top().first;
		int s = q.top().second;

		q.pop();
		if (d[s] < cost) continue;

		for (int i = 0; i < a[s].size(); i++){
			int b = a[s][i].first;
			if (d[b] > d[s] + a[s][i].second){
				d[b] = d[s] + a[s][i].second;
				q.push(make_pair(d[b], b));
			}
		}
	}

	for (int i = 1; i <= n; i++){
		if (d[i] == 2100000000) printf("INF\n");
		else printf("%d\n", d[i]);
	}
	return 0;
}