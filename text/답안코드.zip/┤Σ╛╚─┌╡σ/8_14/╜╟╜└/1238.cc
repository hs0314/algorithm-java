#include <stdio.h>
#include <queue>
#include <vector>
#include <algorithm>

#define INF 200000

using namespace std;

priority_queue < pair <int, int>, vector < pair<int, int> >, greater < pair <int, int> > > pq;
vector < pair <int, int> > li[1001];
vector < pair <int, int> > li_reversed[1001];

int d[1001];
int ans[1001];

void dijkstra(vector < pair <int, int> > *li, int start, int N){
	
	for (int i = 1; i <= N; i++)
		d[i] = INF;

	d[start] = 0;
	pq.push(make_pair(0, start));

	while (!pq.empty()){

		pair <int, int> p = pq.top();
		int c = p.first, s = p.second;
		pq.pop();
		if (d[s] < c) continue;

		for (int i = 0; i < li[s].size(); i++){
			int e = li[s][i].first;
			int cost = li[s][i].second;

			if (d[e] > d[s] + cost){
				d[e] = d[s] + cost;
				pq.push(make_pair(d[e], e));
			}
		}

	}

	for (int i = 1; i <= N; i++)
		ans[i] += d[i];

}
int main(){

	int N, M, X;
	scanf("%d %d %d", &N, &M, &X);
	
	for (int i = 0; i < M; i++){
		int s, e, T;
		scanf("%d %d %d", &s, &e, &T);
		li[s].push_back(make_pair(e, T));
		li_reversed[e].push_back(make_pair(s, T));
	}
	
	dijkstra(li, X, N);
	dijkstra(li_reversed, X, N);

	int ANS = -1;
	for (int i = 1; i <= N; i++)
		ANS = max(ANS, ans[i]);

	printf("%d", ANS);
	return 0;

}
