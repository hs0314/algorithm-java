#include <stdio.h>
#define INF 20000

int heavy_d[101][101];
int light_d[101][101];

int main(){

	int n;
	int m;
	scanf("%d %d", &n, &m);
	
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= n; j++)
			light_d[i][j] = heavy_d[i][j] = INF;
		light_d[i][i] = heavy_d[i][i] = 0;
	}

	for (int i = 0; i < m; i++){
		int h, l;
		scanf("%d %d", &h, &l);
		heavy_d[l][h] = 1;
		light_d[h][l] = 1;
	}

	for (int k = 1; k <= n; k++){
		for (int i = 1; i <= n; i++){
			for (int j = 1; j <= n; j++){
				if (heavy_d[i][j] > heavy_d[i][k] + heavy_d[k][j])
					heavy_d[i][j] = heavy_d[i][k] + heavy_d[k][j];
				if (light_d[i][j] > light_d[i][k] + light_d[k][j])
					light_d[i][j] = light_d[i][k] + light_d[k][j];
			}	
		}
	}

	for (int i = 1; i <= n; i++){
		int ans = 0;
		for (int j = 1; j <= n; j++)
			if (heavy_d[i][j] == INF && light_d[i][j] == INF)
				ans++;
		printf("%d\n", ans);
	}
	
	return 0;

}
