#include <stdio.h>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

priority_queue < pair <int, int>, vector < pair <int, int> >, greater < pair <int, int> > > pq;
vector < pair <int, int> > e;
vector < int > mst;

int ind[10001];

int Find_R(int a){
    
    while (ind[a] != -1) a = ind[a];
    return a;

}

void Union(int R, int a){
    
    int t;
    while (ind[a] != -1) t = a, a = ind[a], ind[t] = R;
    ind[a] = R;

}
int main(){

    int n, m;
    int i;
    scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++)
        ind[i] = -1;

    for (i = 0; i < m; i++){
        int x, y, z;
        scanf("%d %d %d", &x, &y, &z);        
        e.push_back(make_pair(x, y));
        pq.push( make_pair(z, i) );
    }
    
    long long ans = 0;

    while (!pq.empty()){
        
        int ind = pq.top().second, cost = pq.top().first;
        int x = e[ind].first, y = e[ind].second;
        pq.pop();

        int xr = Find_R(x), yr = Find_R(y);
        if (xr == yr) continue;
        if (xr < yr) Union(yr, x);
        else Union(xr, y);
        
        ans += cost;
        mst.push_back(ind);

    }
    
    printf("%lld\n", ans);
    return 0;

}