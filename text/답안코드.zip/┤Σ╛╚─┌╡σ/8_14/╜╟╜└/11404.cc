#include <stdio.h>
#include <algorithm>
#define INF 20000000

using namespace std;

int d[101][101];

int main(){

	int n;
	scanf("%d", &n);
	
	int m;
	scanf("%d", &m);
	
	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++)
			d[i][j] = INF;
		d[i][i] = 0;
	}

	for (int i = 0; i < m; i++){
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		a -= 1, b -= 1;
		d[a][b] = min(d[a][b], c);
	}
	
	for (int k = 0; k < n; k++)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++){
				if (d[i][j] > d[i][k] + d[k][j])
					d[i][j] = d[i][k] + d[k][j];
			}

	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++)
			printf("%d ", d[i][j]==INF?0:d[i][j]);
		printf("\n");
	}
	
	return 0;

}
