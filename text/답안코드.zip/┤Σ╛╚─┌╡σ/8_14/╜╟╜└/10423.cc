#include <stdio.h>
#include <queue>
#include <map>
#include <algorithm>
#include <functional>

using namespace std;

typedef pair <int, pair<int, int> > pii;
priority_queue < pii, vector <pii>, greater <pii> > pq;

int parent[1111];
int n, m, k;
map <int, int> lead;

void weightedUnion(int i, int j){

	int temp = parent[i] + parent[j];
	if (parent[i] > parent[j]) {
		parent[i] = j;
		parent[j] = temp;
	}else {
		parent[j] = i;
		parent[i] = temp;
	}

}

int collapsingFind(int i){
	int root, trail, lead;
	for (root = i; parent[root] >= 0; root = parent[root]);
	for (trail = i; trail != root; trail = lead){
		lead = parent[trail];
		parent[trail] = root;
	}
	return root;
}
bool check(){
	for (int i = 1; i <= n; i++){
		if (parent[i] < 0){
			if (lead[i] != 1) return true;
		}
	}
	return false;
}
int main(){

	scanf("%d %d %d", &n, &m, &k);
	for (int i = 0; i < k; i++){
		int a;
		scanf("%d", &a);
		lead[a] = 1;
	}
	for (int i = 1; i <= m; i++){
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		pq.push(make_pair(c, make_pair(a, b)));
	}

	for (int i = 1; i <= n; i++)
		parent[i] = -1;

	int ans = 0;
	while (!pq.empty() && check()){
	
		pii data = pq.top();
		pq.pop();
		int x = data.second.first , y = data.second.second;
		int cost = data.first;

		int px = collapsingFind(x);
		int py = collapsingFind(y);

		if (px == py) continue;

		if (lead[px] == 1 && lead[py] == 1){
			continue;
		}else if (lead[px] == 1){
			int temp = parent[px] + parent[py];
			parent[px] = temp;
			parent[py] = px;
		}else if (lead[py] == 1){
			int temp = parent[px] + parent[py];
			parent[py] = temp;
			parent[px] = py;
		}else {
			weightedUnion(px, py);
		}
		ans += cost;
	}
	printf("%d", ans);
	return 0;
}