#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector < pair <int, int> > a[1111];
int n;
int ind[1111], d[1111];

int dij(int s, int e){

	for (int i = 0; i <= n; i++){
		ind[i] = 0;
		d[i] = 2123456789;
	}
	d[s] = 0;
	for (int i = 0; i < n; i++){
		
		int start = -1, min = 2123456789;
		for (int j = 1; j <= n; j++){
			if (ind[j] == 0 && d[j] < min){
				min = d[j];
				start = j;
			}
		}
		if (start == -1) return 2123456789;
		ind[start] = 1;
		if (start == e) return d[start];
		for (int j = 0; j < a[start].size(); j++){
			if (ind[a[start][j].first] == 0 && d[a[start][j].first] > d[start] + a[start][j].second){
				d[a[start][j].first] = d[start] + a[start][j].second;
			}
		}
	
	}

}
int check(int start, int end){

	int temp = dij(1, start);
	int temp2 = dij(start, end);
	int temp3 = dij(end, n);

	if (temp == 2123456789 || temp2 == 2123456789 || temp3 == 2123456789) return 2123456789;
	else return temp + temp2 + temp3;

}
int main(){

	int p;
	scanf("%d %d", &n, &p);

	for (int i = 0; i < p; i++){
		
		int x, y, c;
		scanf("%d %d %d", &x, &y, &c);
		a[x].push_back(make_pair(y, c));
		a[y].push_back(make_pair(x, c));
	
	}
	
	int start, end;
	scanf("%d %d", &start, &end);
	
	int ans = check(start, end);
	ans = min(ans, check(end, start));

	if (ans == 2123456789) ans = -1;
	printf("%d", ans);

}