#include <stdio.h>

int ind[1000001];

void Union(int r1, int r2){
	
	if (r1 == r2) return;
	ind[r2] = r1;

}
int Find(int a){
	
	if (ind[a] == -1) return a;
	ind[a] = Find(ind[a]);
	return ind[a];

}
int main(){

	int n, m;
	scanf("%d %d", &n, &m);
	for (int i = 0; i <= n; i++)
		ind[i] = -1;

	for (int i = 0; i < m; i++){
	
		int op, a, b;
		scanf("%d %d %d", &op, &a, &b);
		
		if (op == 0)
			Union(Find(a), Find(b));
		else
			printf("%s\n", Find(a)==Find(b)?"YES":"NO");

	}

	return 0;

}
