#include <stdio.h>
#include <algorithm>

using namespace std;

int t[10];
int n = 4;

int main(){

	int i;

	for (i = 1; i <= n; i++){
	
		scanf("%d", &t[i]);
	
	}

	sort(t + 1, t + 1 + n);

	printf("%d", t[1] * t[3]);

	return 0;
	
}