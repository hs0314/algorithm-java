#include <stdio.h>
#include <string.h>

char Str[111];
int N = 5;
char f[] = "aeiou";

int main(){

    scanf("%s", Str);
    int length = strlen(Str);
    
    int ans = 0;
    for (int i = 0; i < length; i++)
        for (int j = 0; j < N; j++)
            if (Str[i] == f[j])
                ans += 1;
    
    printf("%d", ans);
    return 0;
    
}