#include <stdio.h>
#include <string.h>

int ind[27];
char Str[111];

int main(){

    int i;
    for (i = 'a'; i <= 'z'; i++)
        ind[i - 'a'] = 0;
    
    scanf("%s", Str);
        
    int length = strlen(Str);
    for (i = 0; i < length; i++)
        ind[Str[i] - 'a'] += 1;
        
    for (i = 'a'; i <= 'z'; i++)
        printf("%d ", ind[i - 'a']);
    
    return 0;
    
}