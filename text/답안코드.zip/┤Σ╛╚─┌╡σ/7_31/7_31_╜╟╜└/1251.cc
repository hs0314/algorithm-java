#include <stdio.h>
#include <string.h>

char a[100], v[100], ans[100], pre[100];
void remo(){

	int i, t = strlen(v);
	for (i = 0; i < t; i++) v[i] = '\0';

}
void remo2(){

	int i, t = strlen(pre);
	for (i = 0; i < t; i++) pre[i] = '\0';

}
void rev(){

	int i, t = strlen(v);

	for (i = 0; i < t / 2; i++){
	
		char temp = v[i];
		v[i] = v[t - i - 1];
		v[t - i - 1] = temp;
	
	}

}
int main(){

	gets(a);
	const int n = strlen(a);

	int i, j, k;

	for (i = 0; i < n - 2; i++){
	
		for (j = i + 1; j < n - 1; j++){
		
			int cnt = -1;
			for (k = 0; k <= i; k++){
			
				cnt += 1;
				v[cnt] = a[k];
			
			}
			rev();
			strcat(pre, v);
			remo();
			cnt = -1;
			for (k = i + 1; k <= j; k++){
			
				cnt += 1;
				v[cnt] = a[k];
			
			}
			rev();
			strcat(pre, v);
			remo();
			cnt = -1;
			for (k = j + 1; k < n; k++){
			
				cnt += 1;
				v[cnt] = a[k];
			
			}
			rev();
			strcat(pre, v);
			remo();
			if ((i == 0 && j == 1) || strcmp(pre, ans) == -1) strcpy(ans, pre);
			remo2();

		}
	
	}

	printf("%s", ans);
	return 0;

}