#include <stdio.h>

int main(){
    
    int T;
    scanf("%d", &T);
    
    while (T--){
   
        int n;
        scanf("%d", &n);
        
        int C, total = 0;
        double G, GPA = 0.0;
        
        for (int i = 0; i < n; i++){
            scanf("%d %lf", &C, &G);
            total += C;
            GPA += C * G;
        }
        printf("%d %.1lf\n", total, GPA / total);
        
    }
    
    return 0;
    
}