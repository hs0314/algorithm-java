#include <stdio.h>
#include <deque>
#include <algorithm>

using namespace std;

deque < pair<int, int> > Q;

int main(){

	int T, a, n, m, i;
	scanf("%d", &T);

	while (T--){
	
		scanf("%d %d", &n, &m);
		for (i = 0; i < n; i++){
		
			scanf("%d", &a);
			Q.push_back(make_pair(a, i));
		
		}
		
		int cnt = 0;
		while (1){
		
			for (i = 1; i < Q.size(); i++){
			
				if (Q[0].first < Q[i].first) break;
			
			}
			if (i != Q.size()){
			
				pair <int, int> x;
				x = Q[0];
				Q.pop_front();
				Q.push_back(x);
			
			}else {
				
				cnt += 1;
				if (Q[0].second == m) break;
				Q.pop_front();
			
			}
		
		}
		Q.clear();
		printf("%d\n", cnt);
	
	}
	return 0;

}