#include <stdio.h>
#include <map>

using namespace std;

map <int, bool> v;

int n, q[1100], ans;

int max(int, int);
int main(){
	
	int i, j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++){
	
		scanf("%d", &q[i]);	
	
	}

	for (i = 1; i <= n; i++){
	
		for (j = i; j <= n; j++){
		
			v[q[i] + q[j]] = 1;
		
		}
	
	}

	for (i = 1; i <= n; i++){
	
		for (j = 1; j <= n; j++){
		
			if (v[q[i] - q[j]] == 1){
			
				ans = max(q[i], ans);
			
			}
		
		}
	
	}
	printf("%d", ans);
    return 0;

}
int max(int a, int b){

	if (a > b) return a;
	return b;

}