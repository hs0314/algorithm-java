#include <stdio.h>
#include <stack>

using namespace std;

stack <int> st;
char com[6];

int main(){

	int n, X;
	scanf("%d", &n);
	getchar();

	while (n--){

		scanf("%s", com);

		if (com[1] == 'u'){
			scanf("%d", &X);
			st.push(X);
			getchar();
		}
		else if (com[1] == 'i'){
			printf("%d\n", st.size());
		}
		else if (com[1] == 'm'){
			if (st.empty()) printf("1\n");
			else printf("0\n");
		}
		else if (com[0] == 'p'){
			if (st.empty()) printf("-1\n");
			else {
				printf("%d\n", st.top());
				st.pop();
			}
		}
		else {
			if (st.empty()) printf("-1\n");
			else printf("%d\n", st.top());
		}

	}

	return 0;

}