#include <stdio.h>
#include <string>

using namespace std;

char Str[111];

int main(){
    
    int T, n;
    scanf("%d", &T);
    
    while (T--){
        
        scanf("%d", &n);
        getchar();
        
        string name;
        int maxi = -1, num;
        
        for (int i = 0; i < n; i++){
            scanf("%s %d", Str, &num);
            getchar();
            
            if (maxi < num){
                maxi = num;
                name = Str;
            }
        }
        printf("%s\n", name.c_str());
        
    }
    
    return 0;
        
}