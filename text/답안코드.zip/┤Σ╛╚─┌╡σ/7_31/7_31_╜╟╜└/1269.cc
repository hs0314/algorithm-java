#include <stdio.h>
#include <map>

using namespace std;

map <int, int> mp;

int main(){
    
    int n, m;
    scanf("%d %d", &n, &m);
    
    int elem;
    for (int i = 0; i < n; i++){
        scanf("%d", &elem);
        mp[elem] = 1;
    }
    
    int inter = 0;
    for (int i = 0; i < m; i++){
        scanf("%d", &elem);
        if (mp[elem] == 1)
            inter += 1;
    }
    
    printf("%d", n + m - inter * 2);
    return 0;
    
}