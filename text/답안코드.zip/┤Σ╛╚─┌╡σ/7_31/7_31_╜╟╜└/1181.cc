#include <stdio.h>
#include <algorithm>
#include <string>

using namespace std;

char Str[55];
string wd[20001];

int cmp(string a, string b){
    
    if (a.length() == b.length())
        return a < b;
    return a.length() < b.length();
    
}
int main(){
    
    int n;
    scanf("%d", &n);
    getchar();
    
    for (int i = 0; i < n; i++){
        scanf("%s", Str);
        wd[i] = Str;
    }
    
    sort(wd, wd + n, cmp);
    
    printf("%s\n", wd[0].c_str());
    for (int i = 1; i < n; i++){
        if (wd[i] == wd[i - 1]) continue;
        printf("%s\n", wd[i].c_str());
    }
    return 0;
    
}