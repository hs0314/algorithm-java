#include <stdio.h>
#include <algorithm>

using namespace std;

int A[101000], ans;

int main(){

	int n, m, i;
	scanf("%d %d", &n, &m);

	for (i = 1; i <= n; i++) {
	
		scanf("%d", &A[i]);
	
	}

	sort(A + 1, A + 1 + n);

	int s = 1, e = 1;
	ans = A[n] - A[1];
	while (e != n + 1){
	
		if (A[e] - A[s] < m) e += 1;
		else if (A[e] - A[s] == m) {
			ans = m;
			s += 1;
		}else if (A[e] - A[s] > m) {
			ans = min(ans, A[e] - A[s]);
			s += 1;
		}

	}

	printf("%d", ans);

}