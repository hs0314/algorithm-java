#include <stdio.h>
#include <algorithm>

using namespace std;

int p[110000], m[110000], cnt_p, cnt_m, ans = 2147483647;
int ans1, ans2;

int abs(int a) {

	if (a > 0) return a;
	return -a;

}
int main(){

	int n, i, a;

	scanf("%d", &n);
	for (i = 1; i <= n; i++){
	
		scanf("%d", &a);
		if (a >= 0) p[++cnt_p] = a;
		else m[++cnt_m] = -a;
	
	}

	sort(p + 1, p + cnt_p + 1);
	sort(m + 1, m + cnt_m + 1);
	p[cnt_p + 1] = 2147483647;
	m[cnt_m + 1] = 2147483647;

	if (cnt_p > 1) {ans = p[1] + p[2]; ans1 = p[1], ans2 = p[2];}
	if (cnt_m > 1) {
		if (ans > m[1] + m[2]){
		
			ans = m[1] + m[2];
			ans1 = -m[2];
			ans2 = -m[1];
		
		}
	}

	int ps = 1, ms = 1;

	while (ps <= cnt_p && ms <= cnt_m){
	
		if (ans > abs(p[ps] - m[ms])){
		
			ans = abs(p[ps] - m[ms]);
			ans1 = -m[ms];
			ans2 = p[ps];
		
		}
		if (abs(p[ps + 1] - m[ms]) > abs(p[ps] - m[ms + 1]))
			ms += 1;
		else
			ps += 1;
	
	}

	printf("%d %d", ans1, ans2);
	return 0;

}