#include <stdio.h>
#include <queue>

using namespace std;

priority_queue <int, vector<int>, greater<int> > pq;

int main(){

	int n, i, a;
	scanf("%d", &n);

	for (i = 1; i <= n; i++){
	
		scanf("%d", &a);
		if (a == 0){
		
			if (!pq.empty()){
				printf("%d\n", pq.top());
				pq.pop();
			}else
				printf("0\n");
		
		}else {
		
			pq.push(a);
			
		}
	
	}

	return 0;

}