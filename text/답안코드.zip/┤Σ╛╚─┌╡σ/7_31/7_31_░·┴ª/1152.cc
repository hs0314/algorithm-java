#include <stdio.h>
#include <string.h>

char st[1000010];
int main(){

	gets(st);

	int i, n = strlen(st), cnt = 1;

	for (i = 0; i < n; i++){
	
		if (st[i - 1] == ' ') continue;
		if (st[i] == ' ') cnt += 1;
	
	}
	if (st[n - 1] == ' ') cnt -= 1;
	if (st[0] == ' ') cnt -= 1;
	printf("%d", cnt);

	return 0;

}