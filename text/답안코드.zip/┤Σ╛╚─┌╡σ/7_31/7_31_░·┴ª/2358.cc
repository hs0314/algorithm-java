#include <stdio.h>
#include <algorithm>
#include <map>

using namespace std;

map <int, int> indx, indy;
int ans = 0;

int main(){

	int n, i, x, y;

	scanf("%d", &n);
	for (i = 1; i <= n; i++){
	
		scanf("%d %d", &x, &y);
		indx[x] += 1;
		indy[y] += 1;

		if (indx[x] == 2) ans += 1;
		if (indy[y] == 2) ans += 1;

	}
	
	printf("%d", ans);
	return 0;

}