#include <stdio.h>
#include <deque>
#include <algorithm>

using namespace std;

deque <int> Q;
int ans = 0;

int min(int a, int b){
	
	if (a > b) return b;
	return a;

}
int main(){

	int n, m, i, a, j, cnt;

	scanf("%d %d", &n, &m);
	for (i = 1; i <= n; i++)
		Q.push_back(i);

	for (i = 1; i <= m; i++){
		
		cnt = 0;
		scanf("%d", &a);
		while (Q[0] != a){

			int x = Q[0];
			Q.pop_front();
			Q.push_back(x);
			cnt += 1;

		}
		Q.pop_front();
		ans += min(cnt, (n - i + 1) - cnt);
		
	}

	printf("%d", ans);
	return 0;

}