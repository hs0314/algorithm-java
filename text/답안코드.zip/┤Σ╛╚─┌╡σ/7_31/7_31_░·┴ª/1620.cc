#include <iostream>
#include <map>
#include <algorithm>
#include <string>

using namespace std;

string a;
map <string, int> name;
map <int, string> number;

int main(){

	int n, m, i, j;
	cin >> n >> m;

 	for (i = 1; i <= n; i++){
	
		cin >> a;
		name[a] = i;
		number[i] = a;
	
	}

	for (i = 1; i <= m; i++){
	
		cin >> a;
		if ('A' <= a[0] && 'Z' >= a[0])
			cout << name[a] << endl;
		else{
			int cnt = 0;
			for (j = 0; j < a.length(); j++){
			
				cnt *= 10;
				cnt += a[j];
				cnt -= '0';
			
			}
			cout << number[cnt] << endl;
		}

	}
	return 0;

}