#include <stdio.h>
#include <vector>

using namespace std;

vector <int> ans;

int n, q[110000];
char ans_d[210000];

int main(){

	scanf("%d", &n);

	int i;
	for (i = 1; i <= n; i++){

		scanf("%d", &q[i]);

	}

	int cnt = 1, as = -1;
	for (i = 1; i <= n; i++){

		ans.push_back(i);
		as += 1;
		ans_d[as] = '+';

		while (cnt != n + 1 && ans.size() != 0){

			if (ans.back() == q[cnt]){

				ans.pop_back();
				as += 1;
				ans_d[as] = '-';

			}else break;

			cnt += 1;

		}

	}

	if (cnt == n + 1){

		for (i = 0; i <= as; i++){
			printf("%c\n", ans_d[i]);
		}

	}else printf("NO");

	return 0;

}