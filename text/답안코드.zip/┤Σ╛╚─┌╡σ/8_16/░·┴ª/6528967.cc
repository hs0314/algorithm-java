#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> v;
int ind[1299710];

int main(){

    int T;
    scanf("%d" ,&T);
    
    v.push_back(0);
    for (int i = 2; i <= 1299709; i++){
        if (ind[i] == 0){
            v.push_back(i);
            ind[i] = 1;
            for (long long j = (long long)i * i; j < 1299709; j += i){
                ind[j] = 1;
            }
        }
    }
    
    while (T--){
    
        int n;
        scanf("%d", &n);

        int i;
        for (i = 0; i < v.size(); i++){
            if (v[i] >= n) break;
        }
        if (v[i] == n)
            printf("0\n");
        else
            printf("%d\n", v[i] - v[i - 1]);

    }
    return 0;

}
