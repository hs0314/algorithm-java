#include <stdio.h>

int ind[1111111];

int main(){

    int n, m;
    long long i, j;
    scanf("%d %d", &n, &m);
    ind[1] = 1;
    for (i = 2; i <= m; i++){
        if (ind[i] != 0) continue;
        for (j = i * i; j <= m; j += i){
            ind[j] = 1;
        }
    }
    
    for (i = n; i <= m; i++){
        if (ind[i] == 0) printf("%d\n", i);
    }
    return 0;
    
}