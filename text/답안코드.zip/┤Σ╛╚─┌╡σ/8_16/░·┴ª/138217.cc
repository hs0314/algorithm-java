#include <stdio.h>

int main(){

	long long n, m;

	scanf("%lld %lld", &n, &m);

	while (n){
	
		long long t = n;
		n = m % n;
		m = t;
	
	}

	for (long long i = 1; i <= m; i++) printf("1");

}