#include <stdio.h>

int q[111];

int GCD(int a, int b){
	
	while (b != 0){
		int temp = b;
		b = a % b;
		a = temp;
		
	}

	return a;

}
int main(){

	int n, i;
	scanf("%d", &n);
	for(i = 0; i < n; i++){
		scanf("%d", &q[i]);
	}

	for (i = 1; i < n; i++){
		int G = GCD(q[0], q[i]);
		printf("%d/%d\n", q[0]/G, q[i]/G);
	}

}