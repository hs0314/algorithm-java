#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <long long> v;

int ind[1110000];

int main(){

	long long i, j, flag, ans = 0;

	for (i = 2; i <= 1000000; i++){
		
		flag = 0;
		for (j = 2; j * j <= i; j++){
			if (i % j == 0) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) v.push_back(i * i);
	}

	long long n, m;
	scanf("%lld %lld", &n, &m);

	for (i = 0; i < v.size(); i++){
		for (j = (n / v[i]) * v[i]; j <= m; j+=v[i]){
			if (j < n) continue;
			if (ind[j - n] == 0) {
				ans += 1;
				ind[j - n] = 1;
			}
		}
	}
	printf("%lld\n", m - n + 1 - ans);

}