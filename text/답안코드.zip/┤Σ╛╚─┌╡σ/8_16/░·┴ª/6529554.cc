#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> v;

char str[2000];

int gcd(int a, int b){

    if (a == 0) return b;
    return gcd(b % a, a);

}

int main(){

    int T;
    scanf("%d", &T);

    while (T--){
        
        int a;
        char c = ' ';
        while (c == ' '){
            scanf("%d%c", &a, &c);
            v.push_back(a);
        }

        int ans = 1;
        for (int i = 0; i < v.size(); i++)
            for (int j = i + 1; j < v.size(); j++){
                int temp = gcd(v[i], v[j]);
                ans = max(temp, ans);
            }

        printf("%d\n", ans);
        v.clear();
    
    }

}
