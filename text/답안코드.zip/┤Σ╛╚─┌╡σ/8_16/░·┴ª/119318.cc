#include <stdio.h>

int n = 1000, v[1111], cnt;
int main(){

	int i, j;

	v[1] = 1;
	for (i = 2; i <= n; i++){
	
		if (v[i] == 0){
		
			for (j = i + i; j <= n; j += i)		
				v[j] = 1; 
		
		}
	
	}

	int n, a;
	scanf("%d", &n);

	cnt = 0;
	for (i = 1; i <= n; i++){
	
		scanf("%d", &a);
		if (v[a] == 0) cnt += 1;
	
	}
	printf("%d", cnt);

}