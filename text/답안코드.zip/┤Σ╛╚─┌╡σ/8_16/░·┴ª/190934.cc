#include <stdio.h>

long long exp(long long x, long long n, long long c){

	long long i;
	long long base = x, ans = 1;
	for (i = 0; i <= 33; i++){
	
		if (n & (1LL << i)){
			ans = (ans * base) % c;
		}
		base = (base * base) % c;
	}

	return ans;

}
int main(){

	long long x, y, z;
	scanf("%lld %lld %lld", &x, &y, &z);

	printf("%lld", exp(x, y, z));

}