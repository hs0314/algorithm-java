#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> v;
int ind[10001];

int main(){

    int T;
    scanf("%d", &T);

    for (int i = 2; i <= 10000; i++){
        if (ind[i] == 1) continue;

        v.push_back(i);
        ind[i] = 1;
        for (long long j = (long long)i * i; j <= 10000; j += i)
            ind[j] = 1;

    }

    while (T--){

        int n;
        scanf("%d", &n);

        int s = 0, e = v.size() - 1;
        pair <int, int> ans;

        while (s <= e){

            int a = v[s] + v[e];
            if (a < n)
                s++;
            if (a > n)
                e--;
            if (a == n){
                ans = make_pair(s++, e);
            }

        }

        printf("%d %d\n", v[ans.first], v[ans.second]);

    }
    return 0;

}
