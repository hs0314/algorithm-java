#include <stdio.h>
#include <vector>
#include <map>
#define MAX 31623

using namespace std;

map <int, int> mp;
vector <int> v;

int ind[MAX + 1];
long long ans = 1;
int F = 0;

void factorization(int a){

    int flag = a < 0?-1:1;
    a = a < 0?-a:a;

    int i = 0;
    while (a != 1 && i <= v.size()){

        int temp = i == v.size()?a:v[i];
        if (a % temp != 0) { i++; continue; }

        a /= temp;
        mp[temp] += flag;

        if (flag == -1 && mp[temp] >= 0){
            ans = ans * temp;
            if (ans > 1000000000){
                F = 1;
                ans %= 1000000000;
            }
        }

    }

}
int main(){

    for (int i = 2; i <= MAX; i++){
        if (ind[i] == 1) continue;

        v.push_back(i);
        ind[i] = 1;
        for (int j = i * i; j <= MAX; j += i)
            ind[j] = 1;

    }

    int n;
    scanf("%d", &n);

    int a;
    for (int i = 0; i < n; i++){
        scanf("%d", &a);
        factorization(a);
    }

    int m;
    scanf("%d", &m);
    for (int i = 0; i < m; i++){
        scanf("%d", &a);
        factorization(-a);
    }

    if (F == 1)
        printf("%09lld\n", ans);
    else
        printf("%lld\n", ans);

}
