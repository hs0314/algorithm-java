#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> a;
vector < vector <int> > li;

int n = 3, q[5][5], cnt = 0;
int qx[5] = {0,0,1,-1};
int qy[5] = {1,-1,0,0};
int ans = 33;

void back(int x, int y, int len, int lx, int ly){
	
	if (cnt == 8){
		ans = ans>len?len:ans;
		return;
	}
	if (8 - cnt + len >= ans) return;
	if (len >= ans) return;
	int i;
	for (i = 0; i < 4; i++){
	
		int xx = x + qx[i], yy = y + qy[i];
		if (xx == lx && yy == ly) continue;
		if (1 > xx || 3 < xx || 1 > yy || 3 < yy) continue;

		if (q[xx][yy] == (xx - 1) * 3 + yy) cnt -= 1;
		if (q[xx][yy] == (x - 1) * 3 + y) cnt += 1;
		q[x][y] = q[xx][yy];
		q[xx][yy] = 0;
		back(x + qx[i], y + qy[i], len + 1, x, y);
		if (q[x][y] == (x - 1) * 3 + y) cnt -= 1;
		if (q[x][y] == (xx - 1) * 3 + yy) cnt += 1;
		q[xx][yy] = q[x][y];
		q[x][y] = 0;

	}

}
int main(){

	int i, j, x, y;
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++){
			scanf("%d", &q[i][j]);
			if (q[i][j] == 0) x = i, y = j;	
			if (q[i][j] == (i-1)*3 + j) cnt += 1;
		}

	back(x, y, 0, -1, -1);
	if (ans != 33) {
		printf("%d", ans);
		return 0;
	}
	printf("-1");

}