#include <stdio.h>

int main(){

	int x, k;
	scanf("%d %d", &x, &k);

	long long ans = 0, i = 1;
	ans = x;
	
	while (k != 0){
		if (!(ans & i)){
			ans |= i * (k & 1);
			k >>= 1;
		}
		i <<= 1;
	}

	printf("%lld\n", ans ^ x);
	return 0;

}
