#include <stdio.h>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

map <int, int> mp;

int main(){

	int n, s;
	vector <int> l;
	vector <int> r;
	
	scanf("%d %d", &n, &s);

	for (int i = 0; i < n; i++){
		int a;
		scanf("%d", &a);
		if (i >= n / 2)
			r.push_back(a);
		else
			l.push_back(a);
	}
	
	for (int i = 1; i < (1 << l.size()); i++){
		
		int sum = 0;
		for (int j = i, k = 0; j != 0; j >>= 1, k++)
			sum += (j & 1) * l[k];
	
		if (mp.find(sum) == mp.end())
			mp[sum] = 1;
		else
			mp[sum] += 1;
	
	}
	
	long long ans = mp.find(s) != mp.end()?mp[s]:0;

	for (int i = 1; i < (1 << r.size()); i++){

		int sum = 0;
		for (int j = i, k = 0; j != 0; j >>= 1, k++)
			sum += (j & 1) * r[k];

		if (s - sum == 0) ans += 1;
		if (mp.find(s - sum) != mp.end())
			ans = ans + mp[s - sum];

	}

	printf("%lld\n", ans);
	return 0;

}
