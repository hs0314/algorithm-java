#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> li[1000001];
int dp[1000001][2];
int ind[1000001];

int back(int u, int flag){
	
	ind[u] = 1;
	if (dp[u][flag] != 0) {
		ind[u] = 0;
		return dp[u][flag];
	}

	int sum = flag;
	for (int i = 0; i < li[u].size(); i++){
		int v = li[u][i];
		if (ind[v] == 0) {
			
			if (flag == 0)
				sum += back(v, 1);
			else
				sum += min(back(v, 1), back(v, 0));

		}
	}

	ind[u] = 0;
	return (dp[u][flag] = sum);

}
int main(){

	int n;
	scanf("%d", &n);

	for (int i = 0; i < n - 1; i++){
		int u, v;
		scanf("%d %d", &u, &v);
		li[u].push_back(v);
		li[v].push_back(u);
	}

	printf("%d\n", min(back(1, 0), back(1, 1)));

}
