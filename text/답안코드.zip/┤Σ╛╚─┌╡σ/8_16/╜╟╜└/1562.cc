#include <stdio.h>
#include <string.h>
#define MOD 1000000000

int d[110][11][1 << 10], N;

int stairs(int len, int num, int state){

	if (len == N) return state == (1 << 10) - 1;

	int &ret = d[len][num][state];
	if (ret != -1) return ret;
	ret = 0;

	if (num + 1 <= 9)
		ret = (ret + stairs(len+1, (num+1), state|(1<<(num+1)))) % MOD;
	if (num - 1 >= 0)
		ret = (ret + stairs(len+1, (num-1), state|(1<<(num-1)))) % MOD;
	return ret;

}
int main(){

	scanf("%d", &N);
	memset(d,-1,sizeof(d));
	int i, ans = 0;
	for (i = 1; i <= 9; i++){
		ans = (ans + stairs(1, i, (1 << i))) % MOD;
		ans %= MOD;
	}
	printf("%d", ans);

}