#include <stdio.h>
#include <algorithm>

using namespace std;

char mp[11][11];
int d[11*11][1<<12];

int main(){

	int T;
	scanf("%d", &T);
	
	while (T--){
	
		int m, n;
		scanf("%d %d", &m, &n);

		for (int i = 0; i < m; i++)
			scanf("%s", mp[i]);
		
		int total = 1 << (n + 2);
		int ur = 1 << (n - 1);
		int ul = 1 << (n + 1);
		int l = 1 << 1;
		
		for (int index = 0; index < m * n; index++)
			for (int k = 0; k < total; k++)
				d[index][k] = 0;
		
		if (mp[0][0] == '.')
			d[0][1] = 1;

		for (int index = 1; index < m * n; index++){
			
			int interval = 1;
			if (mp[index / n][index % n] == 'x') interval = 2;

			for (int k = 0; k < total; k += interval){
					d[index][k] = max(d[index-1][ul|(k>>1)],
									  d[index-1][(k>>1)]) + (k&1);
					
					int TAG = ur | l | ul;
					if (index % n == 0) TAG = ur;
					if (index % n == n - 1) TAG = ul | l; 
					if (k & 1) 
						d[index][k] = (k & TAG)?0:d[index][k];
			}

		}
		
		int ans = 0;
		for (int k = 0; k < total; k++)
			ans = max(ans, d[n * m - 1][k]);
		printf("%d\n", ans);

	}   
    return 0;

}
