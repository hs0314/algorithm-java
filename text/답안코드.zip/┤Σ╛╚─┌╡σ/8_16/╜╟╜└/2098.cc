#include <stdio.h>
#include <algorithm>
#include <vector>

using namespace std;

vector <int> v[19];
int d[20][100000];
int q[20][20];

int NumberOfSetBits(int i)
{
	i = i - ((i >> 1) & 0x55555555);
	i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
	return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}
int main(){
	
	int n;
	scanf("%d", &n);

	for (int i = 0; i < (1 << n); i++){
		v[NumberOfSetBits(i)].push_back(i);
		for (int j = 0; j < n; j++){
			d[j][i] = 2100000000;	
		}
	}

	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++){
			scanf("%d", &q[i][j]);
		}
	}
	
	d[0][1] = 0;
	for (int i = 1; i <= n; i++){
		int m = v[i].size();
		for (int j = 0; j < m; j++){
			int x = v[i][j];
			for (int k = 0; k < n; k++){
				if ((x & (1 << k)) == 0) continue;
				for (int l = 0; l < n; l++){
					if (x & (1 << l)) continue;
					if (q[k][l] == 0) continue;
					d[l][x | (1 << l)] = min(d[k][x] + q[k][l], d[l][x | (1 << l)]);
				}
			}
		}
	}
	int ans = 2100000000;
	
	for (int i = 0; i < n; i++){
		if (q[i][0] == 0) continue;
		ans = min(ans, d[i][(1<<n) - 1] + q[i][0]);
	}
	printf("%d", ans);
	return 0;

}
